# Communication Soft

Windows WPF / .NET Framework 4.8 source.

- Six machine rows allow target IP and port configuration.
- Choose Manual or Auto mode.
- MLB SN requires 18 alphanumeric characters; PANEL SN 23; JIG SN 14.
- Load MLB File validates unique 18-character records. In Manual mode press START to send; in Auto mode the validated file is sent automatically.
- In Auto mode, enter a serial and press Enter or Queue Data to send it to the selected machine. Manual mode queues it until START is pressed.
- TCP protocol: `PING`, `DATA|<SN TYPE>|<SERIAL>`, then `START`.
- Send log is saved automatically to `Logs\communication-log.txt` beside the application; no Log button is shown.
- Closing the app asks for confirmation. Standard minimize, maximize/restore, and close controls are enabled.

Build with Visual Studio on Windows and the .NET Framework 4.8 Developer Pack. This source was checked for XML well-formedness but was not compiled/tested here; validate against the actual PDCA Sender PC/server before production use.

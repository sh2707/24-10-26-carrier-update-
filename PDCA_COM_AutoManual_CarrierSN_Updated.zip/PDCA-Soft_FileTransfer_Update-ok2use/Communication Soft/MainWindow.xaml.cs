﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using System.ComponentModel;
using Forms = System.Windows.Forms;

namespace CommunicationSoft
{
    public partial class MainWindow : Window
    {
        private sealed class MachineRow
        {
            public int Number;
            public TextBox NameBox, IpBox, PortBox;
            public TextBlock Status;
            public List<string> Queue = new List<string>();
        }
        private readonly List<MachineRow> _machines = new List<MachineRow>();
        private readonly DispatcherTimer _clock = new DispatcherTimer();
        private readonly string _settingsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Config", "machines.txt");
        private readonly List<string> _fileQueue = new List<string>();
        private readonly string _logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs", "communication-log.txt");
        private bool _sending;
        private bool _autoTextSendInProgress;
        private Forms.NotifyIcon _trayIcon;
        private bool _allowExit;

        public MainWindow()
        {
            InitializeComponent();
            rbAuto.IsChecked = true;
            rbManual.IsChecked = false;
            InitializeTrayIcon();
            DependencyPropertyDescriptor.FromProperty(TextBlock.TextProperty, typeof(TextBlock)).AddValueChanged(StatusText, (s, e) =>
            {
                var message = StatusText.Text ?? string.Empty;
                bool isError = new[] { "error", "failed", "invalid", "rejected", "offline", "duplicate", "no valid", "not enabled", "not in auto", "cannot", "could not" }.Any(k => message.IndexOf(k, StringComparison.OrdinalIgnoreCase) >= 0);
                StatusText.Foreground = isError ? System.Windows.Media.Brushes.Red : System.Windows.Media.Brushes.White;
            });
            rbManual.Checked += (s, e) => rbManual.Foreground = System.Windows.Media.Brushes.White;
            rbAuto.Checked += (s, e) => rbAuto.Foreground = System.Windows.Media.Brushes.White;
            for (int i = 1; i <= 6; i++) AddMachineRow(i);
            LoadSettings();
            SerialBox.KeyDown += SerialBox_KeyDown;
            SerialBox.TextChanged += SerialBox_TextChanged;
            _clock.Interval = TimeSpan.FromSeconds(1);
            _clock.Tick += (s, e) => ClockText.Text = "Date: " + DateTime.Now.ToString("dd-MM-yyyy") + "    Time: " + DateTime.Now.ToString("HH:mm:ss");
            _clock.Start();
            ClockText.Text = "Date: " + DateTime.Now.ToString("dd-MM-yyyy") + "    Time: " + DateTime.Now.ToString("HH:mm:ss");
        }

        private void AddMachineRow(int number)
        {
            var grid = new Grid { Margin = new Thickness(0, 4, 0, 4) };
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(50) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(2, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(2, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(100) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(130) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(180) });
            var row = new MachineRow { Number = number };
            var num = new TextBlock { Text = number.ToString(), FontWeight = FontWeights.Bold, HorizontalAlignment = HorizontalAlignment.Center };
            row.NameBox = new TextBox { Text = "Machine " + number, IsReadOnly = true, IsReadOnlyCaretVisible = false };
            row.IpBox = new TextBox { Text = "192.168.1." + (100 + number) };
            row.PortBox = new TextBox { Text = "56379" };
            row.Status = new TextBlock { Text = "Not tested", Foreground = System.Windows.Media.Brushes.LightGray };
            var test = new Button { Content = "Test" };
            test.Click += async (s, e) => await TestMachineAsync(row);
            var save = new Button { Content = "Save" };
            save.Click += (s, e) => { SaveSettings(); StatusText.Text = "Saved settings for " + row.NameBox.Text + "."; };
            var ping = new Button { Content = "Ping" };
            ping.Click += async (s, e) => await PingMachineAsync(row);
            Grid.SetColumn(num, 0); Grid.SetColumn(row.NameBox, 1); Grid.SetColumn(row.IpBox, 2); Grid.SetColumn(row.PortBox, 3); Grid.SetColumn(row.Status, 4);
            var actions = new StackPanel { Orientation = Orientation.Horizontal };
            actions.Children.Add(test); actions.Children.Add(save); actions.Children.Add(ping); Grid.SetColumn(actions, 5);
            grid.Children.Add(num); grid.Children.Add(row.NameBox); grid.Children.Add(row.IpBox); grid.Children.Add(row.PortBox); grid.Children.Add(row.Status); grid.Children.Add(actions);
            MachineRows.Children.Add(grid); _machines.Add(row);
        }

        private void LoadSettings()
        {
            try
            {
                if (!File.Exists(_settingsPath))
                {
                    string legacy = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Config", "machines.csv");
                    if (!File.Exists(legacy)) return;
                    foreach (var line in File.ReadAllLines(legacy).Skip(1))
                    {
                        var p = line.Split('|'); if (p.Length < 4) continue;
                        int n; if (!int.TryParse(p[0], out n) || n < 1 || n > 6) continue;
                        var r = _machines[n - 1]; r.NameBox.Text = "Machine " + n; r.IpBox.Text = p[2]; r.PortBox.Text = p[3];
                    }
                    return;
                }
                foreach (var line in File.ReadAllLines(_settingsPath).Skip(1))
                {
                    var p = line.Split('|'); if (p.Length < 4) continue;
                    int n; if (!int.TryParse(p[0], out n) || n < 1 || n > 6) continue;
                    var r = _machines[n - 1]; r.NameBox.Text = p[1]; r.IpBox.Text = p[2]; r.PortBox.Text = p[3];
                }
            }
            catch (Exception ex) { StatusText.Text = "Settings load error: " + ex.Message; }
        }
        private void SaveSettings()
        {
            Directory.CreateDirectory(Path.GetDirectoryName(_settingsPath));
            var lines = new List<string> { "# Machine configuration (text format)", "Machine|Name|IP|Port" };
            foreach (var r in _machines) lines.Add(r.Number + "|" + Clean(r.NameBox.Text) + "|" + Clean(r.IpBox.Text) + "|" + Clean(r.PortBox.Text));
            File.WriteAllLines(_settingsPath, lines, Encoding.UTF8);
        }
        private static string Clean(string s) { return (s ?? "").Replace("|", " ").Replace("\r", " ").Replace("\n", " ").Trim(); }
        private void SaveSettings_Click(object sender, RoutedEventArgs e) { try { SaveSettings(); StatusText.Text = "Machine names, IPs and ports saved."; } catch (Exception ex) { StatusText.Text = "Save failed: " + ex.Message; } }

        private async Task<string> SendCommandAsync(MachineRow row, string command)
        {
            int port; if (!int.TryParse(row.PortBox.Text.Trim(), out port) || port < 1 || port > 65535) throw new InvalidOperationException("Invalid port for " + row.NameBox.Text);
            using (var client = new TcpClient())
            {
                client.NoDelay = true;
                await client.ConnectAsync(row.IpBox.Text.Trim(), port);
                using (var stream = client.GetStream())
                using (var reader = new StreamReader(stream, Encoding.UTF8))
                using (var writer = new StreamWriter(stream, new UTF8Encoding(false)) { AutoFlush = true })
                {
                    await writer.WriteLineAsync(command);
                    var responseTask = reader.ReadLineAsync();
                    var completed = await Task.WhenAny(responseTask, Task.Delay(2500));
                    if (completed != responseTask) return "No response (command may still have been delivered).";
                    return await responseTask;
                }
            }
        }
        private async Task TestMachineAsync(MachineRow row)
        {
            try { var result = await SendCommandAsync(row, "PING"); row.Status.Text = result.StartsWith("OK") ? "Online" : "Check response"; row.Status.Foreground = result.StartsWith("OK") ? System.Windows.Media.Brushes.LimeGreen : System.Windows.Media.Brushes.Red; StatusText.Text = row.NameBox.Text + ": " + result; }
            catch (Exception ex) { row.Status.Text = "Offline"; row.Status.Foreground = System.Windows.Media.Brushes.Red; StatusText.Text = row.NameBox.Text + " connection failed: " + ex.Message; }
        }
        private async Task PingMachineAsync(MachineRow row)
        {
            var ip = row.IpBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(ip))
            {
                row.Status.Text = "Invalid IP";
                row.Status.Foreground = System.Windows.Media.Brushes.Red;
                StatusText.Text = row.NameBox.Text + ": ping failed — IP address is empty.";
                return;
            }

            row.Status.Text = "Pinging...";
            row.Status.Foreground = System.Windows.Media.Brushes.LightGray;
            StatusText.Text = "Pinging " + row.NameBox.Text + " (" + ip + ")...";
            try
            {
                using (var ping = new Ping())
                {
                    var reply = await ping.SendPingAsync(ip, 2000);
                    if (reply.Status == IPStatus.Success)
                    {
                        row.Status.Text = "Ping OK " + reply.RoundtripTime + " ms";
                        row.Status.Foreground = System.Windows.Media.Brushes.LimeGreen;
                        StatusText.Text = row.NameBox.Text + " (" + ip + "): Ping successful, " + reply.RoundtripTime + " ms.";
                    }
                    else
                    {
                        row.Status.Text = "Ping failed";
                        row.Status.Foreground = System.Windows.Media.Brushes.Red;
                        StatusText.Text = row.NameBox.Text + " (" + ip + "): Ping failed — " + reply.Status + ". Check network/firewall settings.";
                    }
                }
            }
            catch (Exception ex)
            {
                row.Status.Text = "Ping failed";
                row.Status.Foreground = System.Windows.Media.Brushes.Red;
                StatusText.Text = row.NameBox.Text + " (" + ip + "): Ping failed — " + ex.Message;
            }
        }

        private async void LoadFile_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog { Filter = "Serial files (*.txt;*.csv)|*.txt;*.csv|All files (*.*)|*.*", Multiselect = false };
            if (dlg.ShowDialog() != true) return;
            try
            {
                var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                _fileQueue.Clear();
                int validMatches = 0, ignoredDuplicates = 0;
                var fileText = File.ReadAllText(dlg.FileName);
                foreach (System.Text.RegularExpressions.Match match in
                    System.Text.RegularExpressions.Regex.Matches(fileText, @"(?<![A-Za-z0-9])[A-Za-z0-9]{18}(?![A-Za-z0-9])"))
                {
                    var val = match.Value;
                    validMatches++;
                    if (seen.Add(val)) _fileQueue.Add(val); else ignoredDuplicates++;
                }
                if (_fileQueue.Count == 0)
                {
                    StatusText.Text = "ERROR: No valid unique 18-character MLB SN entries found in the selected file.";
                    return;
                }
                SnTypeBox.SelectedIndex = 0;
                string summary = "File: " + Path.GetFileName(dlg.FileName) + Environment.NewLine +
                    "Valid unique data: " + _fileQueue.Count + Environment.NewLine +
                    "Ignored duplicate data: " + ignoredDuplicates + Environment.NewLine +
                    "Invalid/non-matching entries ignored: " + Math.Max(0, CountNonMatchingLines(fileText)) + Environment.NewLine + Environment.NewLine +
                    "Send these data one by one?";
                if (MessageBox.Show(summary, "Verify Loaded File", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                {
                    _fileQueue.Clear();
                    StatusText.Text = "File send cancelled by user.";
                    return;
                }
                StatusText.Text = "Verified " + _fileQueue.Count + " unique MLB SN entries; ignored duplicates: " + ignoredDuplicates + ".";
                int index = TargetMachineBox.SelectedIndex;
                if (index < 0 || index >= _machines.Count) index = 0;
                if (rbAuto.IsChecked == true) await StartMachineAsync(_machines[index]);
                else StatusText.Text += " Manual mode: press START to send the file data one by one.";
            }
            catch (Exception ex) { StatusText.Text = "File load failed: " + ex.Message; }
        }
        private static int CountNonMatchingLines(string fileText)
        {
            int count = 0;
            foreach (var line in (fileText ?? string.Empty).Split(new[] { "\r\n", "\n", "\r" }, StringSplitOptions.None))
                if (!string.IsNullOrWhiteSpace(line) && !System.Text.RegularExpressions.Regex.IsMatch(line, @"(?<![A-Za-z0-9])[A-Za-z0-9]{18}(?![A-Za-z0-9])")) count++;
            return count;
        }

        private async void QueueData_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var type = ((ComboBoxItem)SnTypeBox.SelectedItem).Content.ToString();
                int length = type == "MLB SN" ? 18 : type == "PANEL SN" ? 23 : 14;
                var serial = SerialBox.Text.Trim();
                if (serial.Length != length || !serial.All(char.IsLetterOrDigit)) { StatusText.Text = type + " must be exactly " + length + " alphanumeric characters."; return; }
                _fileQueue.Add(serial); StatusText.Text = "Queued 1 " + type + " entry.";
                if (rbAuto.IsChecked == true)
                {
                    int index = TargetMachineBox.SelectedIndex;
                    if (index < 0 || index >= _machines.Count) index = 0;
                    await StartMachineAsync(_machines[index]);
                }
                else StatusText.Text += " Manual mode: press START on the intended machine.";
            }
            catch (Exception ex) { StatusText.Text = "Queue error: " + ex.Message; }
        }
        private async void StartSelected_Click(object sender, RoutedEventArgs e)
        {
            int index = TargetMachineBox.SelectedIndex;
            if (index < 0 || index >= _machines.Count) index = 0;
            await StartMachineAsync(_machines[index]);
        }
        private async Task StartMachineAsync(MachineRow row)
        {
            if (_sending) { StatusText.Text = "A send operation is already in progress."; return; }
            if (_fileQueue.Count == 0) { StatusText.Text = "No data queued. Enter a serial or load an MLB file first."; return; }
            _sending = true;
            var sendWatch = Stopwatch.StartNew();
            var batch = _fileQueue.ToList();
            var type = ((ComboBoxItem)SnTypeBox.SelectedItem).Content.ToString();
            try
            {
                int expected = type == "MLB SN" ? 18 : type == "PANEL SN" ? 23 : 14;
                int sent = 0;
                foreach (var serial in batch)
                {
                    if (serial.Length != expected || !serial.All(char.IsLetterOrDigit)) throw new InvalidOperationException("Queue contains a serial not matching " + type + " length " + expected + ". Clear queue and reload data.");
                    var command = "DATA|" + type + "|" + serial;
                    var response = await SendCommandAsync(row, command);
                    WriteLog(row, type, serial, response);
                    if (!response.StartsWith("OK", StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("PDCA rejected data " + (sent + 1) + "/" + batch.Count + ": " + response);
                    sent++;
                    StatusText.Text = "Sending " + sent + "/" + batch.Count + " to " + row.NameBox.Text + " (" + row.IpBox.Text.Trim() + ")";
                }
                var startResponse = await SendCommandAsync(row, "START");
                WriteLog(row, type, "[START]", startResponse);
                sendWatch.Stop();
                double elapsed = Math.Max(sendWatch.Elapsed.TotalSeconds, 0.001);
                StatusText.Text = row.NameBox.Text + ": sent " + sent + "/" + batch.Count + " item(s); " + startResponse + " | Speed: " + (sent / elapsed).ToString("0.00") + " SN/sec (" + sendWatch.Elapsed.TotalMilliseconds.ToString("0") + " ms total)";
                row.Status.Text = "START sent"; row.Status.Foreground = System.Windows.Media.Brushes.LightGreen;
                _fileQueue.Clear(); SerialBox.Clear();
            }
            catch (Exception ex) { WriteLog(row, type, "[BATCH ERROR]", ex.Message); StatusText.Text = "Send/START failed: " + ex.Message; row.Status.Text = "Error"; row.Status.Foreground = System.Windows.Media.Brushes.Red; }
            finally { _sending = false; }
        }
        private void WriteLog(MachineRow row, string type, string serial, string result)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(_logPath));
                string line = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " | Machine=" + Clean(row.NameBox.Text) + " | IP=" + Clean(row.IpBox.Text) + " | Port=" + Clean(row.PortBox.Text) + " | Type=" + Clean(type) + " | Data=" + Clean(serial) + " | Result=" + Clean(result);
                File.AppendAllText(_logPath, line + Environment.NewLine, Encoding.UTF8);
            }
            catch { }
        }

        private async void SerialBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!IsLoaded || rbAuto.IsChecked != true || _sending || _autoTextSendInProgress) return;
            string serial = (SerialBox.Text ?? string.Empty).Trim();
            if (string.IsNullOrEmpty(serial)) return;
            string type = ((ComboBoxItem)SnTypeBox.SelectedItem).Content.ToString();
            int expected = type == "MLB SN" ? 18 : type == "PANEL SN" ? 23 : 14;
            if (serial.Length != expected) return;
            if (!serial.All(char.IsLetterOrDigit))
            {
                StatusText.Text = "ERROR: " + type + " must contain exactly " + expected + " alphanumeric characters.";
                return;
            }
            _autoTextSendInProgress = true;
            try { await QueueDataAndSendAutoAsync(); }
            finally { _autoTextSendInProgress = false; }
        }

        private async Task QueueDataAndSendAutoAsync()
        {
            string type = ((ComboBoxItem)SnTypeBox.SelectedItem).Content.ToString();
            int expected = type == "MLB SN" ? 18 : type == "PANEL SN" ? 23 : 14;
            string serial = SerialBox.Text.Trim();
            if (serial.Length != expected || !serial.All(char.IsLetterOrDigit)) return;
            _fileQueue.Add(serial);
            int index = TargetMachineBox.SelectedIndex;
            if (index < 0 || index >= _machines.Count) index = 0;
            await StartMachineAsync(_machines[index]);
        }

        private async void SerialBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key != Key.Enter || rbAuto.IsChecked != true) return;
            e.Handled = true;
            QueueData_Click(sender, new RoutedEventArgs());
        }

        private async void rbAuto_Checked(object sender, RoutedEventArgs e)
        {
            if (!IsLoaded || rbAuto.IsChecked != true || _fileQueue.Count == 0 || _sending) return;
            int index = TargetMachineBox.SelectedIndex;
            if (index < 0 || index >= _machines.Count) index = 0;
            await StartMachineAsync(_machines[index]);
        }

        private void OpenLog_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (File.Exists(_logPath))
                {
                    Process.Start(new ProcessStartInfo(_logPath) { UseShellExecute = true });
                }
                else
                {
                    StatusText.Text = "Log file does not exist yet.";
                }
            }
            catch (Exception ex) { StatusText.Text = "Could not open send log: " + ex.Message; }
        }

        private void ClearQueue_Click(object sender, RoutedEventArgs e) { _fileQueue.Clear(); SerialBox.Clear(); StatusText.Text = "Queued data cleared."; }

        private void InitializeTrayIcon()
        {
            _trayIcon = new Forms.NotifyIcon
            {
                Text = "Communication Soft",
                Icon = System.Drawing.Icon.ExtractAssociatedIcon(Process.GetCurrentProcess().MainModule.FileName),
                Visible = true
            };
            var menu = new Forms.ContextMenuStrip();
            menu.Items.Add("Open Communication Soft", null, (s, e) => RestoreFromTray());
            menu.Items.Add("Exit", null, (s, e) => ExitFromTray());
            _trayIcon.ContextMenuStrip = menu;
            _trayIcon.DoubleClick += (s, e) => RestoreFromTray();
        }

        private void RestoreFromTray()
        {
            ShowInTaskbar = true;
            Show();
            WindowState = WindowState.Normal;
            Activate();
        }

        private void ExitFromTray()
        {
            _allowExit = true;
            if (_clock != null) _clock.Stop();
            try { SaveSettings(); } catch { }
            if (_trayIcon != null) { _trayIcon.Visible = false; _trayIcon.Dispose(); _trayIcon = null; }
            Close();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!_allowExit)
            {
                var answer = MessageBox.Show(
                    "Minimize Communication Soft to the system tray?",
                    "Confirm Close",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question,
                    MessageBoxResult.Yes);
                if (answer != MessageBoxResult.Yes)
                {
                    e.Cancel = true;
                    return;
                }

                // Preserve the existing tray behavior: keep the application running.
                e.Cancel = true;
                Hide();
                ShowInTaskbar = false;
                if (_trayIcon != null)
                    _trayIcon.ShowBalloonTip(1500, "Communication Soft", "The application is still running in the notification area.", Forms.ToolTipIcon.Info);
                return;
            }
            if (_clock != null) _clock.Stop();
            try { SaveSettings(); } catch { }
            if (_trayIcon != null) { _trayIcon.Visible = false; _trayIcon.Dispose(); _trayIcon = null; }
        }
    }
}